package org.archive.accesscontrol;

public class RuleOracleUnavailableException extends AccessControlException {

    /**
     * 
     */
    private static final long serialVersionUID = 8574598479427378024L;

    public RuleOracleUnavailableException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public RuleOracleUnavailableException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

    public RuleOracleUnavailableException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public RuleOracleUnavailableException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

}
