package org.archive.accesscontrol;

public class RobotsUnavailableException extends AccessControlException {

    /**
     * 
     */
    private static final long serialVersionUID = -6268896797166951256L;

    public RobotsUnavailableException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public RobotsUnavailableException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

    public RobotsUnavailableException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public RobotsUnavailableException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

}
