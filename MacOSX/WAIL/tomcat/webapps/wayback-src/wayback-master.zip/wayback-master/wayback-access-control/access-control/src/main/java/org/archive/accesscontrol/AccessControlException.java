package org.archive.accesscontrol;

public class AccessControlException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 4300180270651774259L;

    public AccessControlException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public AccessControlException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

    public AccessControlException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public AccessControlException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

}
