package org.archive.wayback.resourceindex.ziplines;

/**
 * @author brad
 * @deprecated use Http11BlockLoader
 */
public class RemoteHttp11BlockLoader extends Http11BlockLoader {

}
