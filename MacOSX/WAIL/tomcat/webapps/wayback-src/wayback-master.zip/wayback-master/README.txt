$Id$

For install, system requirements and user manual, please see documentation
at docs/user_manual.html.
